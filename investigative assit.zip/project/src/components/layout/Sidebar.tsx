import React, { useState } from 'react';
import { ChevronDown, AlertCircle, PieChart, FileText, FileDown, Menu } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import DropdownSelect from '../shared/DropdownSelect';

const Sidebar: React.FC = () => {
  const { 
    username, 
    tickets, 
    selectedTicket, 
    setSelectedTicket, 
    activeTab, 
    setActiveTab,
    isProcessing,
    setIsProcessing
  } = useApp();
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleTicketSelect = (ticketId: string) => {
    const ticket = tickets.find((t) => t.id === ticketId);
    setSelectedTicket(ticket || null);
  };

  const handleProcessAlert = () => {
    setIsProcessing(true);
    setActiveTab('process');
  };

  const tabs = [
    { id: 'process', name: 'Process Alert', icon: <AlertCircle size={18} /> },
    { id: 'analyse', name: 'Analyse Data', icon: <PieChart size={18} /> },
    { id: 'summarize', name: 'Summarization', icon: <FileText size={18} /> },
    { id: 'transcript', name: 'Transcript', icon: <FileDown size={18} /> },
  ];

  return (
    <>
      <button 
        className="md:hidden fixed top-4 left-4 z-20 p-2 rounded-md bg-indigo-500 text-white"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      >
        <Menu size={20} />
      </button>
      
      <div className={`bg-gradient-to-b from-indigo-500 to-indigo-700 text-white w-64 flex-shrink-0 ${
        isMobileMenuOpen ? 'fixed inset-y-0 left-0 z-10 transform translate-x-0' : 'transform -translate-x-full md:translate-x-0'
      } transition-transform duration-300 ease-in-out md:relative md:translate-x-0`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-semibold text-white mb-1">
                Welcome,
              </h1>
              <p className="text-indigo-200">{username}</p>
            </div>
            <button 
              className="md:hidden text-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              &times;
            </button>
          </div>
          
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2 text-indigo-200">
              Select Ticket
            </label>
            <DropdownSelect
              options={tickets.map(ticket => ({ 
                value: ticket.id, 
                label: ticket.name 
              }))}
              value={selectedTicket?.id || ''}
              onChange={handleTicketSelect}
              placeholder="Choose a ticket"
            />
          </div>
          
          <button
            className={`w-full py-3 px-4 rounded-lg ${
              selectedTicket 
                ? 'bg-white text-indigo-700 hover:bg-indigo-50 transform hover:scale-105 transition-all duration-200' 
                : 'bg-indigo-400 cursor-not-allowed text-indigo-200'
            } font-medium shadow-lg mb-8`}
            disabled={!selectedTicket}
            onClick={handleProcessAlert}
          >
            Process Alert
          </button>
          
          <nav>
            <ul className="space-y-2">
              {tabs.map((tab) => (
                <li key={tab.id}>
                  <button
                    className={`w-full flex items-center py-3 px-4 rounded-lg transition-all duration-200 ${
                      activeTab === tab.id 
                        ? 'bg-white bg-opacity-20 text-white transform scale-105' 
                        : 'hover:bg-white hover:bg-opacity-10 text-indigo-200'
                    }`}
                    onClick={() => setActiveTab(tab.id as any)}
                  >
                    <span className="mr-3">{tab.icon}</span>
                    {tab.name}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
};

export default Sidebar;