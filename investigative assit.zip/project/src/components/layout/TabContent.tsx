import React from 'react';
import { useApp } from '../../context/AppContext';
import ProcessAlert from '../tabs/ProcessAlert';
import AnalyseData from '../tabs/AnalyseData';
import Summarization from '../tabs/Summarization';
import Transcript from '../tabs/Transcript';

const TabContent: React.FC = () => {
  const { activeTab, selectedTicket, isProcessing } = useApp();

  // If no ticket is selected or not processing, show welcome message
  if (!selectedTicket || !isProcessing) {
    return (
      <div className="flex items-center justify-center h-[80vh]">
        <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-lg">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Welcome to the Ticket Processing System
          </h2>
          <p className="text-gray-600 mb-6">
            Please select a ticket from the dropdown menu and click "Process Alert" to begin working on it.
          </p>
          <div className="p-4 bg-blue-50 rounded-md text-blue-800 text-sm">
            <p>This system helps you efficiently process and analyze tickets using AI assistance.</p>
          </div>
        </div>
      </div>
    );
  }

  // Render the appropriate component based on the active tab
  switch (activeTab) {
    case 'process':
      return <ProcessAlert />;
    case 'analyse':
      return <AnalyseData />;
    case 'summarize':
      return <Summarization />;
    case 'transcript':
      return <Transcript />;
    default:
      return null;
  }
};

export default TabContent;