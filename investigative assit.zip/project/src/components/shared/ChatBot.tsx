import React, { useState, useRef, useEffect } from 'react';
import { Send } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface ChatBotProps {
  placeholder?: string;
  initialMessage?: string;
}

const ChatBot: React.FC<ChatBotProps> = ({ 
  placeholder = 'Type a message...', 
  initialMessage = "Hello! I'm your AI assistant. How can I help you today?"
}) => {
  const { chatMessages, addMessage, activeTab } = useApp();
  const [message, setMessage] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Send initial bot message if no messages exist
  useEffect(() => {
    if (chatMessages.length === 0 && initialMessage) {
      addMessage({
        sender: 'bot',
        text: initialMessage,
      });
    }
  }, [initialMessage, chatMessages.length, addMessage]);
  
  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;
    
    addMessage({
      sender: 'user',
      text: message,
    });
    
    setMessage('');
  };
  
  return (
    <div className="h-[70vh] flex flex-col bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="p-4 bg-blue-50 border-b border-blue-100">
        <h3 className="text-lg font-medium text-blue-800">
          AI Assistant
        </h3>
      </div>
      
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-4">
          {chatMessages.map((msg) => (
            <div 
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] p-3 rounded-lg ${
                  msg.sender === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-200">
        <div className="flex items-center">
          <input
            type="text"
            className="flex-1 border border-gray-300 rounded-l-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder={placeholder}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          <button
            type="submit"
            className="bg-blue-600 text-white p-2 rounded-r-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatBot;