import React from 'react';

interface DataTableProps {
  tableName: string;
}

const DataTable: React.FC<DataTableProps> = ({ tableName }) => {
  // Mock data for different tables
  const tableData = {
    'System Logs': [
      { id: 1, timestamp: '2025-04-12 08:23:45', level: 'ERROR', message: 'Connection timeout in database service' },
      { id: 2, timestamp: '2025-04-12 08:24:12', level: 'WARN', message: 'High memory usage detected' },
      { id: 3, timestamp: '2025-04-12 08:25:30', level: 'INFO', message: 'System recovery initiated' },
      { id: 4, timestamp: '2025-04-12 08:26:45', level: 'INFO', message: 'Database service restarted' },
      { id: 5, timestamp: '2025-04-12 08:27:10', level: 'INFO', message: 'System operational' },
    ],
    'Error Reports': [
      { id: 1, date: '2025-04-12', service: 'Database', count: 23, impact: 'High', resolved: 'No' },
      { id: 2, date: '2025-04-11', service: 'API Gateway', count: 5, impact: 'Medium', resolved: 'Yes' },
      { id: 3, date: '2025-04-10', service: 'Auth Service', count: 12, impact: 'Medium', resolved: 'Yes' },
      { id: 4, date: '2025-04-09', service: 'Payment Processor', count: 8, impact: 'High', resolved: 'Yes' },
    ],
    'User Transactions': [
      { id: 1, user: 'user123', type: 'Purchase', amount: '$45.99', status: 'Completed', date: '2025-04-12' },
      { id: 2, user: 'user456', type: 'Refund', amount: '$12.50', status: 'Pending', date: '2025-04-12' },
      { id: 3, user: 'user789', type: 'Purchase', amount: '$89.99', status: 'Failed', date: '2025-04-12' },
      { id: 4, user: 'user123', type: 'Purchase', amount: '$34.99', status: 'Completed', date: '2025-04-11' },
    ],
    'Performance Metrics': [
      { id: 1, metric: 'Response Time', value: '1.2s', threshold: '1.0s', status: 'Warning' },
      { id: 2, metric: 'CPU Usage', value: '78%', threshold: '85%', status: 'Normal' },
      { id: 3, metric: 'Memory Usage', value: '92%', threshold: '80%', status: 'Critical' },
      { id: 4, metric: 'API Errors', value: '0.5%', threshold: '1%', status: 'Normal' },
    ],
  };
  
  const data = tableData[tableName as keyof typeof tableData] || [];
  
  if (data.length === 0) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-800 mb-3">No data available</h3>
      </div>
    );
  }
  
  // Get column headers from the first data item
  const columns = Object.keys(data[0]).filter(key => key !== 'id');
  
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h3 className="text-lg font-medium text-gray-800 mb-3">{tableName}</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {columns.map((column) => (
                <th
                  key={column}
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {column}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((row) => (
              <tr key={row.id}>
                {columns.map((column) => (
                  <td
                    key={`${row.id}-${column}`}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                  >
                    {row[column as keyof typeof row]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;