import React from 'react';
import { CheckCircle, Circle } from 'lucide-react';

interface Step {
  id: number;
  title: string;
  completed: boolean;
}

interface StepTrackerProps {
  steps: Step[];
}

const StepTracker: React.FC<StepTrackerProps> = ({ steps }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm h-full">
      <h3 className="text-lg font-medium text-gray-800 mb-4">
        Progress Tracker
      </h3>
      
      <div className="space-y-4">
        {steps.map((step, index) => (
          <div key={step.id} className="relative">
            {/* Step content */}
            <div className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center">
                {step.completed ? (
                  <CheckCircle className="w-6 h-6 text-green-500" />
                ) : (
                  <Circle className="w-6 h-6 text-gray-300" />
                )}
              </div>
              <div className="ml-4">
                <h4 className={`text-md font-medium ${step.completed ? 'text-green-800' : 'text-gray-700'}`}>
                  {step.title}
                </h4>
                <p className="text-sm text-gray-500">
                  {step.completed 
                    ? 'Completed' 
                    : index > 0 && !steps[index - 1].completed 
                      ? 'Waiting for previous step' 
                      : 'In progress'}
                </p>
              </div>
            </div>
            
            {/* Connector line */}
            {index < steps.length - 1 && (
              <div className="absolute top-8 left-4 w-0.5 h-8 bg-gray-200"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default StepTracker;