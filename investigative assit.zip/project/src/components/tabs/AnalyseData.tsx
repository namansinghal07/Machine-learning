import React, { useState } from 'react';
import ChatBot from '../shared/ChatBot';
import DropdownSelect from '../shared/DropdownSelect';
import DataTable from '../shared/DataTable';
import { useApp } from '../../context/AppContext';
import { Database, Upload } from 'lucide-react';

const DataAnalysisChatBot: React.FC<{ dataSource: string; selectedName?: string }> = ({ 
  dataSource, 
  selectedName 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm h-full">
      <div className="p-4 bg-indigo-50 border-b border-indigo-100">
        <h3 className="text-lg font-medium text-indigo-800">
          Data Analysis Assistant
        </h3>
        <p className="text-sm text-indigo-600 mt-1">
          Ask questions about your {dataSource} to gain insights
        </p>
      </div>
      
      <div className="p-4">
        <div className="chat-messages space-y-4 h-[400px] overflow-y-auto">
          {/* Chat messages will be rendered here */}
        </div>
        
        <div className="mt-4 border-t border-gray-200 pt-4">
          <div className="flex items-center">
            <input
              type="text"
              className="flex-1 border border-gray-300 rounded-l-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder={`Ask about the ${selectedName || dataSource}...`}
            />
            <button
              className="bg-indigo-600 text-white px-6 py-2 rounded-r-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              Analyze
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const AnalyseData: React.FC = () => {
  const { 
    dataTables, 
    selectedTable, 
    setSelectedTable,
    document,
    setDocument
  } = useApp();
  
  const [dataSource, setDataSource] = useState<'table' | 'document'>('table');
  
  const handleTableSelect = (tableId: string) => {
    const table = dataTables.find((t) => t.id === tableId);
    setSelectedTable(table || null);
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setDocument(e.target.files[0]);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">
          Analyse Data
        </h2>
        <p className="text-gray-600">
          View and analyze data related to the ticket. You can ask questions about the data or upload documents for analysis.
        </p>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
        <div className="flex space-x-4 mb-6">
          <button
            className={`flex items-center px-6 py-3 rounded-lg transition-all duration-200 ${
              dataSource === 'table' 
                ? 'bg-indigo-600 text-white shadow-lg transform scale-105' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setDataSource('table')}
          >
            <Database size={18} className="mr-2" />
            Data Tables
          </button>
          <button
            className={`flex items-center px-6 py-3 rounded-lg transition-all duration-200 ${
              dataSource === 'document' 
                ? 'bg-indigo-600 text-white shadow-lg transform scale-105' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            onClick={() => setDataSource('document')}
          >
            <Upload size={18} className="mr-2" />
            Upload Document
          </button>
        </div>
        
        {dataSource === 'table' ? (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Data Table
            </label>
            <DropdownSelect
              options={dataTables.map(table => ({ 
                value: table.id, 
                label: table.name 
              }))}
              value={selectedTable?.id || ''}
              onChange={handleTableSelect}
              placeholder="Choose a data table"
            />
          </div>
        ) : (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload Document for Analysis
            </label>
            <div className="flex items-center justify-center w-full">
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-8 h-8 mb-3 text-gray-500" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500">PDF, DOC, TXT, CSV (MAX. 10MB)</p>
                </div>
                <input 
                  type="file" 
                  className="hidden" 
                  onChange={handleFileUpload}
                  accept=".pdf,.doc,.docx,.txt,.csv"
                />
              </label>
            </div>
            {document && (
              <div className="mt-3 text-sm text-gray-600">
                Uploaded: {document.name}
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <DataAnalysisChatBot 
            dataSource={dataSource === 'table' ? 'data' : 'document'}
            selectedName={dataSource === 'table' ? selectedTable?.name : document?.name}
          />
        </div>
        <div>
          {dataSource === 'table' && selectedTable && (
            <DataTable tableName={selectedTable.name} />
          )}
          {dataSource === 'document' && document && (
            <div className="bg-white p-4 rounded-lg shadow-sm h-full">
              <h3 className="text-lg font-medium text-gray-800 mb-3">Document Preview</h3>
              <div className="p-4 bg-gray-100 rounded border border-gray-200 h-64 flex items-center justify-center">
                <p className="text-gray-500 text-center">
                  Document preview for "{document.name}"<br />
                  <span className="text-sm">(Preview not available in this demo)</span>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalyseData;