import React from 'react';
import ChatBot from '../shared/ChatBot';
import StepTracker from '../shared/StepTracker';
import { useApp } from '../../context/AppContext';

const ProcessAlert: React.FC = () => {
  const { selectedTicket, steps } = useApp();

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-semibold text-indigo-800 mb-4">
          Alert Details
        </h2>
        <div className="space-y-4">
          <div className="p-4 bg-indigo-50 rounded-lg">
            <h3 className="text-lg font-medium text-indigo-900 mb-2">Ticket Information</h3>
            <p className="text-indigo-700">ID: {selectedTicket?.id}</p>
            <p className="text-indigo-700">Name: {selectedTicket?.name}</p>
          </div>
          <div className="p-4 bg-amber-50 rounded-lg">
            <h3 className="text-lg font-medium text-amber-900 mb-2">Priority Status</h3>
            <p className="text-amber-700">High Priority - Immediate Action Required</p>
          </div>
          <div className="p-4 bg-emerald-50 rounded-lg">
            <h3 className="text-lg font-medium text-emerald-900 mb-2">System Impact</h3>
            <p className="text-emerald-700">Affecting core system functionality</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ChatBot 
            placeholder="Ask about the alert or how to resolve it..."
            initialMessage={`I'm here to help you process the alert for ticket "${selectedTicket?.name}". Based on the initial analysis, this appears to be a critical issue affecting system performance. How would you like to proceed?`}
          />
        </div>
        <div>
          <StepTracker steps={steps} />
        </div>
      </div>
    </div>
  );
};

export default ProcessAlert;