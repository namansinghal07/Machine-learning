import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import Button from '../shared/Button';
import { FileText } from 'lucide-react';

const Summarization: React.FC = () => {
  const { chatMessages, selectedTicket } = useApp();
  const [summary, setSummary] = useState<string>('');
  
  const generateSummary = () => {
    if (chatMessages.length === 0) {
      setSummary("No conversation data available yet. Start chatting in the Process Alert or Analyse Data tabs to generate a summary.");
      return;
    }
    
    // Count user and bot messages
    const userMessages = chatMessages.filter(msg => msg.sender === 'user').length;
    const botMessages = chatMessages.filter(msg => msg.sender === 'bot').length;
    
    // Get the last few messages for context
    const recentMessages = chatMessages.slice(-3);
    
    // Look for completion indicators in messages
    const isCompleted = chatMessages.some(msg => 
      msg.text.toLowerCase().includes('resolved') || 
      msg.text.toLowerCase().includes('completed') ||
      msg.text.toLowerCase().includes('verify the solution')
    );
    
    const summaryText = `
# Ticket Processing Summary

## Overview
**Ticket:** ${selectedTicket?.name || 'No ticket selected'}
**Status:** ${isCompleted ? '✅ Resolved' : '🔄 In Progress'}
**Conversation Volume:** ${userMessages + botMessages} messages (${userMessages} from user, ${botMessages} from AI)

## Key Points
${chatMessages.some(msg => msg.text.toLowerCase().includes('identify')) ? '- ✓ Issue has been identified\n' : ''}
${chatMessages.some(msg => msg.text.toLowerCase().includes('root cause')) ? '- ✓ Root cause analysis completed\n' : ''}
${chatMessages.some(msg => msg.text.toLowerCase().includes('solution') || msg.text.toLowerCase().includes('fix')) ? '- ✓ Solution has been proposed\n' : ''}
${chatMessages.some(msg => msg.text.toLowerCase().includes('verify') || msg.text.toLowerCase().includes('test')) ? '- ✓ Solution has been verified\n' : ''}

## Recent Context
${recentMessages.map(msg => `- ${msg.sender === 'user' ? '👤' : '🤖'} ${msg.text}`).join('\n')}

## Conclusion
${isCompleted 
  ? 'The ticket has been successfully resolved based on the conversation history.' 
  : 'The ticket is still being processed. Further actions may be required.'}
`;
    
    setSummary(summaryText);
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Conversation Summary
            </h2>
            <p className="text-gray-600 mt-1">
              Generate an AI-powered summary of your conversation and progress.
            </p>
          </div>
          <Button
            variant="primary"
            size="lg"
            icon={<FileText size={18} />}
            onClick={generateSummary}
          >
            Generate Summary
          </Button>
        </div>
      </div>
      
      {summary && (
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="prose max-w-none">
            <pre className="whitespace-pre-wrap font-sans text-gray-800 bg-gray-50 p-6 rounded-lg">
              {summary}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default Summarization;