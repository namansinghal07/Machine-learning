import React, { useState } from 'react';
import { Download, FileText } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import Button from '../shared/Button';

const Transcript: React.FC = () => {
  const { chatMessages, selectedTicket } = useApp();
  const [editableTranscript, setEditableTranscript] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };
  
  const generateTranscript = () => {
    if (chatMessages.length === 0) return '';
    
    const transcript = chatMessages.map(msg => {
      const time = formatDate(msg.timestamp);
      const sender = msg.sender === 'user' ? 'You' : 'AI Assistant';
      return `[${time}] ${sender}: ${msg.text}`;
    }).join('\n\n');
    
    const header = `Transcript for Ticket: ${selectedTicket?.name || 'Unnamed Ticket'}\nDate: ${formatDate(new Date())}\n\n`;
    return header + transcript;
  };
  
  const handleEdit = () => {
    if (!isEditing) {
      setEditableTranscript(generateTranscript());
    }
    setIsEditing(!isEditing);
  };
  
  const downloadTranscript = (format: 'txt' | 'pdf' | 'doc') => {
    const content = isEditing ? editableTranscript : generateTranscript();
    const mimeTypes = {
      txt: 'text/plain',
      pdf: 'application/pdf',
      doc: 'application/msword'
    };
    
    const blob = new Blob([content], { type: mimeTypes[format] });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript-${selectedTicket?.id || 'ticket'}-${Date.now()}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">
              Conversation Transcript
            </h2>
            <p className="text-gray-600 mt-1">
              Review, edit, and download the complete conversation history.
            </p>
          </div>
          <div className="flex space-x-3">
            <Button
              variant="outline"
              size="md"
              onClick={handleEdit}
            >
              {isEditing ? 'Save Changes' : 'Edit Transcript'}
            </Button>
            <div className="relative group">
              <Button
                variant="primary"
                size="md"
                icon={<Download size={18} />}
                onClick={() => downloadTranscript('doc')}
                disabled={chatMessages.length === 0}
              >
                Download
              </Button>
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <button
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 rounded-t-lg"
                  onClick={() => downloadTranscript('txt')}
                >
                  Download as TXT
                </button>
                <button
                  className="w-full text-left px-4 py-2 hover:bg-gray-100"
                  onClick={() => downloadTranscript('doc')}
                >
                  Download as DOC
                </button>
                <button
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 rounded-b-lg"
                  onClick={() => downloadTranscript('pdf')}
                >
                  Download as PDF
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {chatMessages.length > 0 ? (
          <div className="mt-6">
            {isEditing ? (
              <textarea
                value={editableTranscript}
                onChange={(e) => setEditableTranscript(e.target.value)}
                className="w-full h-[60vh] p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            ) : (
              <div className="space-y-4 max-h-[60vh] overflow-y-auto p-4 bg-gray-50 rounded-lg">
                {chatMessages.map((message) => (
                  <div 
                    key={message.id}
                    className={`p-3 rounded-lg ${
                      message.sender === 'user' 
                        ? 'bg-indigo-100 text-indigo-900 ml-8' 
                        : 'bg-gray-100 text-gray-800 mr-8'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-semibold">
                        {message.sender === 'user' ? 'You' : 'AI Assistant'}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatDate(message.timestamp)}
                      </span>
                    </div>
                    <p>{message.text}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="p-8 text-center text-gray-500">
            <FileText size={48} className="mx-auto mb-4 text-gray-400" />
            <p className="mb-2">No conversation history available yet.</p>
            <p className="text-sm">Start chatting in the Process Alert or Analyse Data tabs to generate a transcript.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Transcript;