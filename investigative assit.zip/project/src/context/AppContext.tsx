import React, { createContext, useContext, useState, ReactNode } from 'react';

// Define types
type Ticket = {
  id: string;
  name: string;
};

type ChatMessage = {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
};

type Step = {
  id: number;
  title: string;
  completed: boolean;
};

type Tab = 'process' | 'analyse' | 'summarize' | 'transcript';

type DataTable = {
  id: string;
  name: string;
};

interface AppContextType {
  username: string;
  tickets: Ticket[];
  selectedTicket: Ticket | null;
  setSelectedTicket: (ticket: Ticket | null) => void;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  chatMessages: ChatMessage[];
  addMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  clearMessages: () => void;
  steps: Step[];
  updateStep: (stepId: number, completed: boolean) => void;
  dataTables: DataTable[];
  selectedTable: DataTable | null;
  setSelectedTable: (table: DataTable | null) => void;
  document: File | null;
  setDocument: (file: File | null) => void;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  resetAll: () => void;
}

// Create context with default values
const AppContext = createContext<AppContextType>({
  username: '',
  tickets: [],
  selectedTicket: null,
  setSelectedTicket: () => {},
  activeTab: 'process',
  setActiveTab: () => {},
  chatMessages: [],
  addMessage: () => {},
  clearMessages: () => {},
  steps: [],
  updateStep: () => {},
  dataTables: [],
  selectedTable: null,
  setSelectedTable: () => {},
  document: null,
  setDocument: () => {},
  isProcessing: false,
  setIsProcessing: () => {},
  resetAll: () => {},
});

const initialSteps: Step[] = [
  { id: 1, title: 'Identify Issue', completed: false },
  { id: 2, title: 'Analyze Root Cause', completed: false },
  { id: 3, title: 'Apply Fix', completed: false },
  { id: 4, title: 'Verify Solution', completed: false },
];

// Create provider component
export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [username, setUsername] = useState<string>('John Doe');
  const [tickets, setTickets] = useState<Ticket[]>([
    { id: '1', name: 'System Outage - Database #2341' },
    { id: '2', name: 'API Gateway Error #5623' },
    { id: '3', name: 'Payment Processing Failure #8971' },
    { id: '4', name: 'User Authentication Issue #4532' },
  ]);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('process');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [steps, setSteps] = useState<Step[]>(initialSteps);
  const [dataTables, setDataTables] = useState<DataTable[]>([
    { id: '1', name: 'System Logs' },
    { id: '2', name: 'Error Reports' },
    { id: '3', name: 'User Transactions' },
    { id: '4', name: 'Performance Metrics' },
  ]);
  const [selectedTable, setSelectedTable] = useState<DataTable | null>(null);
  const [document, setDocument] = useState<File | null>(null);

  const resetAll = () => {
    setActiveTab('process');
    setChatMessages([]);
    setSteps(initialSteps);
    setSelectedTable(null);
    setDocument(null);
    setIsProcessing(false);
  };

  const addMessage = (message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage = {
      ...message,
      id: Date.now().toString(),
      timestamp: new Date(),
    };
    
    setChatMessages(prev => [...prev, newMessage]);
    
    if (message.sender === 'user') {
      setTimeout(() => {
        let botResponse: string;
        
        if (activeTab === 'process') {
          botResponse = generateProcessResponse(message.text);
          updateStepsBasedOnConversation(message.text);
        } else if (activeTab === 'analyse') {
          botResponse = generateAnalysisResponse(message.text, selectedTable?.name);
        } else {
          botResponse = "I'm here to help! What would you like to know?";
        }
        
        addMessage({
          sender: 'bot',
          text: botResponse,
        });
      }, 1000);
    }
  };

  const clearMessages = () => {
    setChatMessages([]);
  };

  const updateStep = (stepId: number, completed: boolean) => {
    setSteps(prev => 
      prev.map(step => 
        step.id === stepId ? { ...step, completed } : step
      )
    );
  };

  const updateStepsBasedOnConversation = (message: string) => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('identify') || lowerMessage.includes('what is the issue')) {
      updateStep(1, true);
    } else if (lowerMessage.includes('root cause') || lowerMessage.includes('why is this happening')) {
      updateStep(1, true);
      updateStep(2, true);
    } else if (lowerMessage.includes('fix') || lowerMessage.includes('solution') || lowerMessage.includes('resolve')) {
      updateStep(1, true);
      updateStep(2, true);
      updateStep(3, true);
    } else if (lowerMessage.includes('verify') || lowerMessage.includes('test') || lowerMessage.includes('confirm')) {
      updateStep(1, true);
      updateStep(2, true);
      updateStep(3, true);
      updateStep(4, true);
    }
  };

  const generateProcessResponse = (message: string): string => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
      return `Hello! I'm here to help you process the ticket${selectedTicket ? ` "${selectedTicket.name}"` : ''}. What can I assist you with?`;
    } else if (lowerMessage.includes('identify') || lowerMessage.includes('what is the issue')) {
      return `Based on the information available, this appears to be ${selectedTicket?.name || 'an issue with the system'}. The symptoms indicate a potential problem with the database connection. Let's investigate further.`;
    } else if (lowerMessage.includes('root cause') || lowerMessage.includes('why is this happening')) {
      return `After analyzing the logs, I've determined that the root cause is likely a timeout in the connection pool due to high traffic. The system is not properly releasing connections back to the pool.`;
    } else if (lowerMessage.includes('fix') || lowerMessage.includes('solution') || lowerMessage.includes('resolve')) {
      return `I recommend implementing the following fix: 1) Increase the connection pool size temporarily, 2) Add proper connection closing in the middleware, 3) Implement a connection timeout monitoring system.`;
    } else if (lowerMessage.includes('verify') || lowerMessage.includes('test') || lowerMessage.includes('confirm')) {
      return `Let's verify the solution by: 1) Monitoring connection pool metrics for the next hour, 2) Running a load test with simulated traffic, 3) Checking for any error logs. The initial tests look promising - connections are being properly released.`;
    } else {
      return `I understand you're asking about ${message}. To help you better with this ticket${selectedTicket ? ` "${selectedTicket.name}"` : ''}, could you provide more specific details about what you're trying to achieve?`;
    }
  };

  const generateAnalysisResponse = (message: string, tableName: string | undefined): string => {
    if (!tableName && !document) {
      return "Please select a data table or upload a document first so I can help analyze the data.";
    }
    
    if (tableName) {
      return `Based on the ${tableName} data, I can provide the following analysis: This appears to show a pattern of increased errors during peak usage hours. The correlation between user load and system performance is significant.`;
    } else {
      return "I've analyzed the uploaded document and found several key insights related to the current issue. The document mentions similar patterns that occurred in previous incidents.";
    }
  };

  const value = {
    username,
    tickets,
    selectedTicket,
    setSelectedTicket: (ticket: Ticket | null) => {
      setSelectedTicket(ticket);
      resetAll();
    },
    activeTab,
    setActiveTab,
    chatMessages,
    addMessage,
    clearMessages,
    steps,
    updateStep,
    dataTables,
    selectedTable,
    setSelectedTable,
    document,
    setDocument,
    isProcessing,
    setIsProcessing,
    resetAll,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};